import typer
import json
from pathlib import Path
from rich.console import Console
from rich.table import Table
from rich.prompt import Prompt

# Initialize the Typer app and Rich Console
app = typer.Typer()
console = Console()

# Define the path for the bookmarks file
BOOKMARKS_FILE = Path("bookmarks.json")

class BookmarkManager:
    """Handles the addition, deletion, and listing of bookmarks."""

    def __init__(self):
        self.bookmarks = self.load_data()

    def load_data(self):
        """Load bookmarks from the bookmarks file."""
        if BOOKMARKS_FILE.exists():
            with open(BOOKMARKS_FILE, "r") as f:
                return json.load(f)
        return {}

    def save_data(self):
        """Save bookmarks to the bookmarks file."""
        with open(BOOKMARKS_FILE, "w") as f:
            json.dump(self.bookmarks, f, indent=4)

    def add_bookmark(self, title, url):
        """Add a bookmark."""
        self.bookmarks[title] = url
        self.save_data()
        console.print(f"Bookmark '{title}' added successfully!", style="bold green")

    def list_bookmarks(self):
        """List all bookmarks."""
        if not self.bookmarks:
            console.print("No bookmarks found.", style="bold red")
        else:
            table = Table(title="Bookmarks")
            table.add_column("Title", justify="left", style="cyan")
            table.add_column("URL", justify="left", style="magenta")

            for title, url in self.bookmarks.items():
                table.add_row(title, url)

            console.print(table)

    def delete_bookmark(self, title):
        """Delete a bookmark."""
        if title in self.bookmarks:
            del self.bookmarks[title]
            self.save_data()
            console.print(f"Bookmark '{title}' deleted.", style="bold yellow")
        else:
            console.print(f"Bookmark '{title}' not found.", style="bold red")

# Initialize the Bookmark Manager
bookmark_manager = BookmarkManager()

# Command to add a new bookmark
@app.command()
def add():
    '''Add a new bookmark with a title and URL.'''
    title = Prompt.ask("Enter the bookmark title")
    url = Prompt.ask("Enter the bookmark URL")
    bookmark_manager.add_bookmark(title, url)

# Command to list all bookmarks
@app.command()
def list():
    '''Display all saved bookmarks.'''
    bookmark_manager.list_bookmarks()

# Command to delete a bookmark by title
@app.command()
def delete():
    '''Remove a bookmark by its title.'''
    title = Prompt.ask("Enter the title of the bookmark to delete")
    bookmark_manager.delete_bookmark(title)

if __name__ == "__main__":
    app()
